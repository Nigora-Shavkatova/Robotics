# Lab 6 — Odometry, digits 63

| File | What it is |
|---|---|
| `trajectory_sim.qrs` | Program run in the TRIK Studio simulator |
| `trajectory_real.qrs` | Same program, run on the real TRIK robot |
| `odometry_data_sim.txt` | Raw simulator log (`x,y,time`, m / m / ms) |
| `odometry_data_real.txt` | Raw real-robot log (`x,y,time`, m / m / ms) |
| `Lab6_odometry.ipynb` | Colab notebook: trajectories plot, error-vs-time plot, printed errors |
| `results_preview.png` | The two notebook plots, for quick viewing |

Program: every loop it updates differential-drive odometry from encoders E3 (left) / E4 (right),
R = 0.043 m, B = 0.198 m, and appends `x,y,time` to the log. Path = 0.4 m segments with
in-place 90° right turns; each move ends when the left encoder passes its target `T[i]`.

> Note: the robot first wrote the log as one line with a literal `\n` after each sample
> (the Write block had `"\\n"`). The program now writes `"\n"`; the real log was split into
> lines with no change to the numbers.

## Measured end point

| | x, m | y, m |
|---|---|---|
| Odometry (last line of `odometry_data_real.txt`) | 0.67 | 0.34 |
| Tape measure | _fill in_ | _fill in_ |
| Difference | _fill in_ | _fill in_ |

Frame: start = (0, 0), x = initial heading, y = to the robot's left.

## Results

| | Simulator | Real robot (odometry) |
|---|---|---|
| Run time | 32.9 s | 21.0 s |
| Sample period | 20 ms | ~135 ms |
| Path length (from log) | 5.15 m | 3.41 m |
| Heading at the end | −1018° (≈ 102° per corner) | −743° (≈ 74° per corner) |
| Left-wheel rotation seen by odometry | 9203° | 6253° |
| End point | (0.48, −0.10) m | (0.67, 0.34) m |

Sim vs real position error (real timestamps): **final 0.93 m, max 1.06 m** (at 18 s).
Planned end point of the "63": (0.60, −0.40) m.

## Discussion

The trajectories agree only at the very start: the real odometry's first straight is about 0.30 m
instead of 0.40 m, and each real corner is about 74° while the simulator's is about 102° (the turn
factor `kq = 1.15` adds 15% to every corner, so even the model does not draw a clean 63).
The real program had to turn the left wheel at least 9045° to finish all 21 moves, but its odometry
adds up to only 6253° (≈ 69%), with the same left/right ratio as the simulator, so every logged
distance and angle is scaled down by the same ~30%. Wheel slip or a wrong R or B cannot explain this,
because they change the motion or the conversion, not the number of encoder degrees counted; the
likely cause is lost encoder increments: the Odometry block reads each encoder twice (once for `dL`,
again for `pL = encoder3`), and on the real robot, with its slow ~135 ms loop, the rotation between
the two reads is never counted, while the simulator reads instantly and loses nothing.
On top of that, the real "straight" lines bend slightly, which is the unequal wheels / motors effect
from the lecture. The robot does not know it is wrong: its odometry under-reports both distance and
heading, so its believed end point (0.67, 0.34) m differs from the tape-measured one by _(fill in)_ m.
